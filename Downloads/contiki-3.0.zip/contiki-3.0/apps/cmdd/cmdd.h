#ifndef CMDD_H_
#define CMDD_H_

#include "contiki.h"

PROCESS_NAME(cmdd_process);

#endif /* CMDD_H_ */
